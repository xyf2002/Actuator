"""
Contains the processor, the audio player, the visualiser and the LED controller

"""

