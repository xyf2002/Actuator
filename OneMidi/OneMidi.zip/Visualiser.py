"""
Takes a timeline of notes being played and visualises it
"""

